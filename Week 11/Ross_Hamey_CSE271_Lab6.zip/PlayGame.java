// imports
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.util.Scanner;

public class PlayGame {

   // instance vars
   private LinkedList<Hand> playerHands;
   private DeckList funDeck;
   private int numPlayers;
   private int[] playerScores;

   // constructor, which takes in numPlayers and handSize, two ints
   public PlayGame(int numPlayers, int handSize) throws Exception {
      // assigning instance variables
      this.numPlayers = numPlayers;
      this.playerHands = new LinkedList<Hand>();
      this.playerScores = new int[numPlayers];
      
      // creating a deck and shuffling it, then assignign to instance var
      DeckList deck = new DeckList();
      deck.shuffle();
      this.funDeck = deck;
      
      // throwing exception if player num isnt as expected
      if (numPlayers < 2 || numPlayers > 4) {
         throw new Exception("Error - number of players must be between 2 and 4 (inclusive).");
      // otherwise, iterate over players and create a new hand, and add it to playerHands
      } else {
         for (int i = 0; i < numPlayers; i++) {
            Hand thisHand = new Hand(handSize);
            playerHands.add(thisHand);
         }
      }
      
      // call dealHands
      dealHands();
   }
   
   /**
    * private dealHands method, which simply iterates over all player hands and grabs
    * the hand size, iterating up to that hand size and grabbing a card from the deck,
    * then adding said card to the hand
    * @param args unused
    * @return nothing (void)
    */
   private void dealHands() {
      // iterating over player hands, and adding cards for their current handsize
      // in a nested loop, then sorting by rank
      for (int i = 0; i < playerHands.size(); i++) {
         Hand thisHand = playerHands.get(i);
         for (int j = 0; j < thisHand.getHandSize(); j++) {
            Card currentCard = funDeck.getCard();
            thisHand.addCard(currentCard);
         }
         thisHand.sortHandByRank();
      }
   }
   
   /**
    * getNumPlayers method, which simply returns the # of players
    * @param args unused
    * @return this.numPlayers, the number of players in the game
    */
   public int getNumPlayers() {
      return this.numPlayers;
   }
   
   /**
    * getHand method, which simply returns the hand of said player
    * @param playerNum, an int representing the player
    * @return this.playerHands.get(playerNum), a Hand representing the player
    * hand of player playerNum
    */
   public Hand getHand(int playerNum) {
      return this.playerHands.get(playerNum);
   }
   
   /**
    * showHand method, which simply shows the player hand at a specified
    * player number
    * @param playerNum, an int representing the player
    * @return nothing (void)
    */
   public void showHand(int playerNum) {
      this.playerHands.get(playerNum).showHand();
   }
   
   /**
    * hasFourOfaKind method, which takes in a player number and then returns
    * true or false depending on if the user has four of a kind of one card rank
    * @param playerNum, an int representing the player
    * @return true if player has four of a kind, false if they do not
    */
   public boolean hasFourOfaKind(int playerNum) {
      // sentinel boolean, grabbing playerHand, assigning
      // a rank Array, and creating a HashMap to keep track of rank count
      boolean result = false;
      Hand playerHand = playerHands.get(playerNum);
      int[] rankArray = new int[playerHand.getHandSize()];
      Map<Integer, Integer> rankMap = new HashMap();
      
      // add cards to array
      for (int i = 0; i < playerHand.getHandSize(); i++) {
			Card s = playerHand.getCard(i);
         int cardRank = s.getRank();
         rankArray[i] = cardRank;
		}
      
      // for rank in array, check if our HashMap contains the rank - if it
      // does, increment the value of the key by 1
      for (Integer rank : rankArray) {
         if (rankMap.containsKey(rank)) {
            rankMap.put(rank, rankMap.get(rank) + 1);
         // otherwise add our rank to the hashmap with a value of 1
         } else {
            rankMap.put(rank, 1);
         }
      }
      
      // iterate over our hashmap values (occurrences), and look for one where
      // a rank has 4 occurrences
      for (int occurrences : rankMap.values()) {
         if (occurrences == 4) {
            result = true;
            break;
         }
      }
      
      // return result
      return result;
   }
   
   /**
    * hasWantedCard method, which checks if the user has a specified
    * card of a specific rank, and returns a boolean representing if they do
    * (true) or if they do not (false)
    * @param playerNum, an int representing the player
    * @param checkRank, an int representing the card rank to check for
    * @return true if target user has a card of matching rank, otherwise false
    */
   public boolean hasWantedCard(int playerNum, int checkRank) {
      // getting hand and creating array
      Hand playerHand = playerHands.get(playerNum);
      int[] rankArray = new int[playerHand.getHandSize()];
      
      // adding card ranks to array
      for (int i = 0; i < playerHand.getHandSize(); i++) {
      	Card s = playerHand.getCard(i);
         int cardRank = s.getRank();
         rankArray[i] = cardRank;
      }
      
      // checking array for rank, return true if found
      for (int i = 0; i < rankArray.length; i++) {
         if (rankArray[i] == checkRank) {
            return true;
         }
      }
      
      // otherwise we return false
      return false;
   }
   
   /**
    * updateScore method, which simply takes in a player number and
    * increments their score
    * @param playerNum, an int representing the player
    * @return nothing (void)
    */
   public void updateScore(int playerNum) {
      playerScores[playerNum] += 1;
   }
   
   /**
    * showScores method, which simply displays the scores of all players
    * @param args unused
    * @return nothing (void)
    */
   public void showScores() {
      for (int i = 0; i < playerScores.length; i++) {
         System.out.println("Player " + i + ": " + playerScores[i] + " points");
      }
   }
   
   /**
    * determineWinner method, which checks users and their scores and determines
    * if their is a single winner (true), or a draw / no winner (false) and returns
    * said boolean to the user
    * @param args unsued
    * @return true if there is a single winner, otherwise false
    */
   public boolean determineWinner() {
      // set default highest score, winning player #, and winner bool to false
      int highestScore = 0;
      int winningPlayer = -1;
      boolean winner = false;
      
      // iterate over playerscores, if one score is higher than highest score we
      // log appropriate info and set highest score
      for (int i = 0; i < playerScores.length; i++) {
         if (playerScores[i] > highestScore) {
            winner = true;
            highestScore = playerScores[i];
            winningPlayer = i;
         // otherwise if scores are equal, we set winner to false (currently a tie)
         // and winningPlayer back to -1
         } else if (playerScores[i] == highestScore) {
            winner = false;
            winningPlayer = -1;
         }
      }
      
      // prompting user with winner / draw / no winner message accordingly and returning winner bool
      if (winner == true) {
         System.out.println("Player " + winningPlayer + " wins with a score of " + highestScore + "!");
         return winner;
      } else if (winner == false && highestScore > 0) {
         System.out.println("There was a draw with a highest score of " + highestScore + ".");
         return winner;
      } else {
         System.out.println("No player had a score over 0, thus there was no winner.");
         return winner;
      }
   }
   
   // playNow function to test the game
   public void playNow() throws Exception {
      // input, and # of players
      Scanner inp = new Scanner(System.in);
      int players = 0;
      
      // repeatedly prompt user for valid # of players
      while (true) {
         System.out.print("Enter # of players: ");
         players = Integer.parseInt(inp.nextLine());
         if (players >= 2 && players <= 4) {
            break;
         } else {
            System.out.println("Invalid # of players. Pick a number from 2 and 4.");
         }
      }
      
      // start our game and set endGame bool to true
      PlayGame game = new PlayGame(2, 7);
      boolean endGame = true;
      
      // while our bool is true, we print the users hands each round
      while (endGame) {
         System.out.println("=== PLAYER 0'S HAND ===");
         game.showHand(0);
         System.out.println();
         System.out.println("=== PLAYER 1'S HAND ===");
         game.showHand(1);
         System.out.println();
      
         // and we take turns for each player, allowing them to enter a card rank to check for and which player to target
         // their check on
         for (int i = 0; i < players; i++) {
            boolean validInputs = false;
            int cardRank = 0;
            int playerNumber = 0;
            
            // we will repeatedly prompt for these values until valid
            while (!validInputs) {
               System.out.print("Enter a card rank to check for Player " + i + ": ");
               cardRank = Integer.parseInt(inp.nextLine());
               System.out.print("Enter the player # to check for said card (number between 0 and " + (players - 1) + ", not including yourself!): ");
               playerNumber = Integer.parseInt(inp.nextLine());
               if (playerNumber >= 0 && playerNumber <= players && playerNumber != i) {
                  if (cardRank >= 2 && cardRank <= 14) {
                     validInputs = true;
                  }
               } else {
                  System.out.println("One or more invalid inputs. Please check your values.");
               }
            }
            
            // THIS is where the root of my major blocker / error is coming from. To sum it up, my code is not
            // producting the expected outputs in this spot. Ideally if I had finished this, I would check whether
            // the user has the card here, then remove the card from one player's hand and add it to the other.
            // After, I would check if the current player has a book or not, and then remove cards if so and increment score,
            // or do nothing if they have no book.
        
            // Unfortunately here, when I try calling my hasWantedCard method, I get false in situations where I SHOULD be
            // getting true (so an error with my logic), and after hours of looking into this issue I can't seem to figure out
            // what is wrong / get past it. Below are some things I've tried with my code to print out the player hands, but for
            // some reason calling my game's showHand method produces a different output than a targeted hand's showHand method - though
            // ideally both would be the same.
               
            System.out.println(playerNumber); // prints out as 1, as expected (when inputting 1 to player select prompt)
            System.out.println();
            Hand targetHand = this.playerHands.get(playerNumber);
            Hand homeHand = playerHands.get(i);
            targetHand.showHand(); // should print out same as game.showHand(1), but doesn't
            System.out.println();
            game.showHand(1); // prints out entirely different hand compared to above
            System.out.println();
            game.showHand(playerNumber); // prints out same hand as above
            System.out.println();
            this.playerHands.get(playerNumber).showHand(); // same call as game.showHand, but prints out same as original target.showHand() and not game.showHand(1)
            System.out.println();
             
             // EXAMPLE RUN:
//           === PLAYER 0'S HAND ===
//           Six of Hearts
//           Eight of Clubs
//           Eight of Spades
//           Jack of Clubs
//           Queen of Hearts
//           King of Spades
//           Ace of Diamonds
//           
//           === PLAYER 1'S HAND ===
//           Two of Clubs
//           Four of Clubs
//           Five of Hearts
//           Seven of Spades
//           Jack of Diamonds
//           Jack of Hearts
//           Queen of Spades

            // checked for rank 11 (Jack) in player 1's hand - end result returns false (should be true)
            System.out.println(hasWantedCard(playerNumber, cardRank));
         }
         
         if (endGame == false) {
            break;
         }
      }
      
      // testing core methods
      System.out.println(game.hasFourOfaKind(1));
      System.out.println(game.hasWantedCard(1, 5));
      game.showScores();
      game.determineWinner();
   }
   
}