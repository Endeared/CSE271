public class PlayGameTester {

   public static void main(String[] args) throws Exception {
   
      PlayGame game = new PlayGame(2, 7);
      game.playNow();
   
   }

}